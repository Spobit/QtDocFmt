***

`Version:` Qt 5.13.0, Qt4.10.0-beta2 (4.98.3)

`Declaration:`

`Defination:`

`Reference:`

`Keyword:`

***

[TOC]

***

# `Brief Introduction`

# `Detailed Description`

# `Data Struct`

## `Type Declaration`

``` {class=line-numbers}
struct Q_CORE_EXPORT QMetaObject
{

///> 0. Prepare
public:
    typedef void (*StaticMetacallFunction)(QObject *, QMetaObject::Call, int, void **);

///> 1. Properties
public:
    struct
    {
        const QMetaObject *         superdata;
        const QByteArrayData *      stringdata;
        const uint *                data;
        StaticMetacallFunction      static_metacall;
        const QMetaObject * const * relatedMetaObjects;
        void *                      extradata;
    } d;

///> 2. Constructors

///> 3. Functions

}
```

`superdata`

QMetaObject class object, it is the menber 'staticMetaObject' of parent class that inheritance relation.
similar to \<superClass\>::staticMetaObject.

see UnderstandQtExample/Example1:

``` {class=line-numbers}
/*moc_object.cpp*/

QT_INIT_METAOBJECT const QMetaObject Object::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Object.data,
    qt_meta_data_Object,
    qt_static_metacall,
    nullptr,
    nullptr
} };
```

``` {class=line-numbers}
/*moc_object.i*/

const QMetaObject Object::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Object.data,
    qt_meta_data_Object,
    qt_static_metacall,
    nullptr,
    nullptr
} };
```

`stringdata`

a string sequence. such as meta call fuctions.

`data`

`static_metacall`

meta call fuction pointers.

`relatedMetaObjects`

`extradata`

reserved for future use.


## `Constructor`

``` {class=line-numbers}

```

## `Memory Model`

``` {class=line-numbers}

```

# `Properties`

# `Public Types`

# `Public Functions`

# `Reimplemented Public Functions`

# `Public Slots`

# `Static Public Members`

# `Protected Types`

# `Protected Functions`

# `Reimplemented Protected Functions`

# `Protected Slots`

# `staitc Protected Members`

# `Private Types`

# `Private Functions`

# `Private Slots`

# `Static Private Members`

# `Signals`

# `Related Non-Members`

# `Macros`