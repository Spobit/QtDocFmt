***

`Version:` Qt 5.13.0, Qt4.10.0-beta2 (4.98.3)

`Declaration:`

`Defination:`

`Reference:`

`Keyword:`

***

[TOC]

***

# `Brief Introduction`

# `Detailed Description`

# `Data Struct`

## `Type Declaration`

``` {class=line-numbers}
class Q_CORE_EXPORT QObjectData
{
///> 0. Prepare

///> 1. Properties
public:
    QObject *q_ptr;
    QObject *parent;
    QObjectList children;

    uint isWidget : 1;
    uint blockSig : 1;
    uint wasDeleted : 1;
    uint isDeletingChildren : 1;
    uint sendChildEvents : 1;
    uint receiveChildEvents : 1;
    uint isWindow : 1; //for QWindow
    uint deleteLaterCalled : 1;
    uint unused : 24;
    int postedEvents;
    QDynamicMetaObjectData *metaObject;

///> 2. Constructors
public:
    virtual ~QObjectData() = 0;

///> 3. Functions
public:
    QMetaObject *dynamicMetaObject() const;
};
```

`q_ptr`

parent object, who own the 'd' object.

see QObject::QObject(QObject *parent).

`parent`

parent object, who own the 'q' object.

see:
- QObject::QObject(QObject *parent) ==>
- QObject::setParent(QObject *parent) ==>
- QObjectPrivate::setParent_helper(QObject *o);

`children`

child object set.

`isWidget`

whether the object is a widget object.

`blockSig`

whether block the signals.

`wasDeleted`

destroy flag. It will be set to true when destroy object.
see QObject::~QObject().

`isDeletingChildren`

`sendChildEvents`

if we should send ChildAdded and ChildRemoved events to parent.

`receiveChildEvents`

if we should receive events from children.

`isWindow`

if the object is a window.

`deleteLaterCalled`

`unused`

reserve.

`postedEvents`

`metaObject`

## `Constructor`

``` {class=line-numbers}

```

## `Memory Model`

``` {class=line-numbers}
[QObjectData]
    __vptr
    q_ptr
    parent
    children
    isWidget
    blockSig
    wasDeleted
    isDeletingChildren
    sendChildEvents
    receiveChildEvents
    isWindow
    deleteLaterCalled
    unused
    postedEvents
    metaObject

[SIZE]
48 == sizeof(QObjectData)
+8      __vptr
+8      q_ptr
+8      parent
+8      children
+1/8    isWidget
+1/8    blockSig
+1/8    wasDeleted
+1/8    isDeletingChildren
+1/8    sendChildEvents
+1/8    receiveChildEvents
+1/8    isWindow
+1/8    deleteLaterCalled
+3      unused
+4      postedEvents
+8      metaObject
```

# `Properties`

# `Public Types`

# `Public Functions`

# `Reimplemented Public Functions`

# `Public Slots`

# `Static Public Members`

# `Protected Types`

# `Protected Functions`

# `Reimplemented Protected Functions`

# `Protected Slots`

# `staitc Protected Members`

# `Private Types`

# `Private Functions`

# `Private Slots`

# `Static Private Members`

# `Signals`

# `Related Non-Members`

# `Macros`