***

`Version:` Qt 5.13.0, Qt4.10.0-beta2 (4.98.3)

`Declaration:`

`Defination:`

`Reference:`

`Keyword:`

***

[TOC]

***

# `Brief Introduction`

# `Detailed Description`

# `Data Struct`

## `Type Declaration`

``` {class=line-numbers}
class Q_CORE_EXPORT QObjectPrivate : public QObjectData
{
///> 0. Prepare
public:
    struct ExtraData
    {
        ExtraData() {}
    #ifndef QT_NO_USERDATA
        QVector<QObjectUserData *> userData;
    #endif
        QList<QByteArray> propertyNames;
        QVector<QVariant> propertyValues;
        QVector<int> runningTimers;
        QList<QPointer<QObject> > eventFilters;
        QString objectName;
    };

    typedef void (*StaticMetaCallFunction)(QObject *, QMetaObject::Call, int, void **);

    struct Connection
    {
        QObject *sender;
        QObject *receiver;
        union {
            StaticMetaCallFunction callFunction;
            QtPrivate::QSlotObjectBase *slotObj;
        };
        // The next pointer for the singly-linked ConnectionList
        Connection *nextConnectionList;
        //senders linked list
        Connection *next;
        Connection **prev;
        QAtomicPointer<const int> argumentTypes;
        QAtomicInt ref_;
        ushort method_offset;
        ushort method_relative;
        uint signal_index : 27; // In signal range (see QObjectPrivate::signalIndex())
        ushort connectionType : 3; // 0 == auto, 1 == direct, 2 == queued, 4 == blocking
        ushort isSlotObject : 1;
        ushort ownArgumentTypes : 1;
        Connection() : nextConnectionList(nullptr), ref_(2), ownArgumentTypes(true) {
            //ref_ is 2 for the use in the internal lists, and for the use in QMetaObject::Connection
        }
        ~Connection();
        int method() const { Q_ASSERT(!isSlotObject); return method_offset + method_relative; }
        void ref() { ref_.ref(); }
        void deref() {
            if (!ref_.deref()) {
                Q_ASSERT(!receiver);
                delete this;
            }
        }
    };

    // ConnectionList is a singly-linked list
    struct ConnectionList {
        ConnectionList() : first(nullptr), last(nullptr) {}
        Connection *first;
        Connection *last;
    };

    struct Sender
    {
        QObject *sender;
        int signal;
        int ref;
    };

///> 1. Properties
public:
    // extra data set by the user
    ExtraData *extraData;
    // id of the thread that owns the object
    QThreadData *threadData;

    QObjectConnectionListVector *connectionLists;

    // linked list of connections connected to this object
    Connection *senders;
    // object currently activating the object
    Sender *currentSender;
    mutable quint32 connectedSignals[2];

    union {
        // should only be used when QObjectData::isDeletingChildren is set
        QObject *currentChildBeingDeleted;
        //extra data used by the declarative module
        QAbstractDeclarativeData *declarativeData;
    };

    // these objects are all used to indicate that a QObject was deleted
    // plus QPointer, which keeps a separate list
    QAtomicPointer<QtSharedPointer::ExternalRefCountData> sharedRefcount;

///> 2. Constructors
public:
    QObjectPrivate(int version = QObjectPrivateVersion);
    virtual ~QObjectPrivate();

///> 3. Functions

}

```

## `Constructor`

``` {class=line-numbers}
QObjectPrivate::QObjectPrivate(int version)
    : threadData(0), connectionLists(0), senders(0),
      currentSender(0), currentChildBeingDeleted(0)
{
#ifdef QT_BUILD_INTERNAL
    // Don't check the version parameter in internal builds.
    // This allows incompatible versions to be loaded, possibly for testing.
    Q_UNUSED(version);
#else
    if (Q_UNLIKELY(version != QObjectPrivateVersion))
        qFatal("Cannot mix incompatible Qt library (version 0x%x) with this library (version 0x%x)",
                version, QObjectPrivateVersion);
#endif

    // QObjectData initialization
    q_ptr = 0;
    parent = 0;                                 // no parent yet. It is set by setParent()
    isWidget = false;                           // assume not a widget object
    blockSig = false;                           // not blocking signals
    wasDeleted = false;                         // double-delete catcher
    isDeletingChildren = false;                 // set by deleteChildren()
    sendChildEvents = true;                     // if we should send ChildAdded and ChildRemoved events to parent
    receiveChildEvents = true;
    postedEvents = 0;
    extraData = 0;
    connectedSignals[0] = connectedSignals[1] = 0;
    metaObject = 0;
    isWindow = false;
    deleteLaterCalled = false;
}
```

``` {class=line-numbers}
QObjectPrivate::~QObjectPrivate()
{
    if (extraData && !extraData->runningTimers.isEmpty()) {
        if (Q_LIKELY(threadData->thread == QThread::currentThread())) {
            // unregister pending timers
            if (threadData->hasEventDispatcher())
                threadData->eventDispatcher.load()->unregisterTimers(q_ptr);

            // release the timer ids back to the pool
            for (int i = 0; i < extraData->runningTimers.size(); ++i)
                QAbstractEventDispatcherPrivate::releaseTimerId(extraData->runningTimers.at(i));
        } else {
            qWarning("QObject::~QObject: Timers cannot be stopped from another thread");
        }
    }

    if (postedEvents)
        QCoreApplication::removePostedEvents(q_ptr, 0);

    threadData->deref();

    if (metaObject) metaObject->objectDestroyed(q_ptr);

#ifndef QT_NO_USERDATA
    if (extraData)
        qDeleteAll(extraData->userData);
#endif
    delete extraData;
}
```

## `Memory Model`

``` {class=line-numbers}
[QObjectPrivate]
    [QObjectData]
    extraData
    threadData
    connectionLists
    senders
    currentSender
    connectedSignals
    currentChildBeingDeleted
    sharedRefcount

[SIZE]
?? == sizeof(QObjectPrivate)
+48     [QObjectData]
+8      extraData
+8      threadData
+8      connectionLists
+8      senders
+8      currentSender
+8      connectedSignals
+8      currentChildBeingDeleted
+8      sharedRefcount
```

# `Properties`

# `Public Types`

# `Public Functions`

# `Reimplemented Public Functions`

# `Public Slots`

# `Static Public Members`

# `Protected Types`

# `Protected Functions`

# `Reimplemented Protected Functions`

# `Protected Slots`

# `staitc Protected Members`

# `Private Types`

# `Private Functions`

# `Private Slots`

# `Static Private Members`

# `Signals`

# `Related Non-Members`

# `Macros`