# `1`

``` {class=line-numbers}
#define Q_DISABLE_COPY(Class) \
    Class(const Class &) Q_DECL_EQ_DELETE;\
    Class &operator=(const Class &) Q_DECL_EQ_DELETE;
```

# `2`

``` {class=line-numbers}
#define Q_DISABLE_COPY(Class) \
    Class(const Class &) delete;\
    Class &operator=(const Class &) delete;
```

# `3`

``` {class=line-numbers}
Q_DISABLE_COPY(QObject)
```

``` {class=line-numbers}
QObject(const QObject &) delete;\
QObject &operator=(const QObject &) delete;
```
