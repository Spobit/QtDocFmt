***
`Version:` Qt 5.12.1, QtCreate 4.8.1
`Declaration:`
`Defination:`
`Reference:`
`Keyword:`
***
[TOC]
***



# `Brief Introduction`



# `Detailed Description`



# `Data Struct`
## `Type Declaration`
```
class Q_CORE_EXPORT QString
{
///> 0. Prepare
///> 1. Properties
///> 2. Constructor
///> 3. Functions
}
```
## `Constructor`
```

```
## `Memory Model`
```

```

# `Properties`

# `Public Types`
# `Public Functions`
# `Reimplemented Public Functions`
# `Public Slots`
# `Static Public Members`

# `Protected Types`
# `Protected Functions`
# `Reimplemented Protected Functions`
# `Protected Slots`
# `staitc Protected Members`

# `Private Types`
# `Private Functions`
# `Private Slots`
# `Static Private Members`

# `Signals`
# `Related Non-Members`
# `Macros`
