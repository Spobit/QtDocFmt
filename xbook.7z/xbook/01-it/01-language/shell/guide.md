***
[toc]
***

# `Introduction`

## `What is a shell`

A Unix shell is both a command interpreter and a programming language. As a command interpreter, the shell provides the user interface to the rich set of gnu utilities. The programming language features allow these utilities to be combined.

Unix shell既是一个命令解释器,又是一种编程语言.作为命令解释器,它为gnu工具集提供了用户接口.作为编程语言,它允许这些工具组合使用.

Shells may be used interactively or non-interactively. In interactive mode, they accept input typed from the keyboard. When executing non-interactively, shells execute commands read from a file.

A shell allows execution of gnu commands, both synchronously and asynchronously. The shell waits for synchronous commands to complete before accepting more input; asynchronous commands continue to execute in parallel with the shell while it reads and executes additional commands.

Shells also provide a small set of built-in commands (builtins) implementing functionality impossible or inconvenient to obtain via separate utilities.

Like any high-level language, the shell provides:

- variables
- flow control constructs
- quoting
- functions

## `What is Bash`

> Bash is the shell, or command language interpreter, for the gnu operating system. The name is an acronym for the ‘Bourne-Again SHell’.

> Bash is largely compatible with sh and incorporates useful features from the Korn shell ksh and the C shell csh.

# `Base Shell Features`

- commands
- control structures
- shell functions
- shell parameters
- shell expansions
- redirections

## `Shell Syntax`

### `Shell Workflow`

1. Reads its input from a file or from the user’s terminal.

2. Breaks the input into words and operators, obeying the quoting. These tokens are separated by metacharacters. Alias expansion is performed by this step.

3. Parses the tokens into simple and compound commands.

4. Performs the various shell expansions, breaking the expanded tokens into lists of filenames and commands and arguments.

5. Performs any necessary redirections and removes the redirection operators and their operands from the argument list.

6. Executes the command.

7. Optionally waits for the command to complete and collects its exit status.

### `Quoting`

Quoting is used to remove the special meaning of certain characters or words to the shell.

Each of the shell metacharacters has special meaning to the shell and must be quoted if it is to represent itself.

There are three quoting mechanisms:

- Escape Character
- Single Quotes
- Double Quotes

#### `Escape Character`

A non-quoted backslash ‘\\’ is the Bash escape character.

It preserves the literal value of the next character that follows, but exception of newline. If a \\newline pair appears, and the backslash itself is not quoted, the \newline is treated as a line continuation.

Bash转义字符保持随后字符的字面值,但是新行除外.如果出现转义字符与新行对,新行被视作续行.

#### `Single Quotes`

Enclosing characters in single quotes (‘’’) preserves the literal value of each character within the quotes. A single quote may not occur between single quotes, even when preceded by a backslash.

在单引号对内的字符串保留字面值.单引号对内不能出现单引号,即使前面有反斜杠.

#### `Double Quotes`

Enclosing characters in double quotes (‘"’) preserves the literal value of all characters within the quotes, with the exception of ‘\$’, ‘‘’, ‘\\’, and, when history expansion is enabled, ‘\!’.

在双引号对内的字符串保留字面值,但是 ‘\$’, ‘‘’, ‘\\’, ‘\!’ 除外.

The characters ‘\$’ and ‘‘’ retain their special meaning within double quotes. The backslash retains its special meaning only when followed by one of the following characters: ‘\$’, ‘‘’, ‘"’, ‘\\’, or newline. Within double quotes, backslashes that are followed by one of these characters are removed. Backslashes preceding characters without a special meaning are left unmodified.

在双引号对内, ‘\$’, ‘‘’保留特殊含义.反斜杠也保留特殊含义,当其后跟随字符 ‘\$’, ‘‘’, ‘\\’ 或新行时,不是这些字符时,反斜杠保留.

A double quote may be quoted within double quotes by preceding it with a backslash.

The special parameters ‘\*’ and ‘@’ have special meaning when in double quotes.

### `Comments`

# `Abbreviation and Terminology`

## `POSIX`

A family of open system standards based on Unix. Bash is primarily concerned with the Shell and Utilities portion of the posix 1003.1 standard.

## `Blank`

A space or tab character.

## `Builtin`

A command that is implemented internally by the shell itself, rather than by an executable program somewhere in the file system.

## `Control Operator`

A token that performs a control function. It is a newline or one of the following:
‘||’, ‘&&’, ‘&’, ‘;’, ‘;;’, ‘;&’, ‘;;&’, ‘|’, ‘|&’, ‘(’, or ‘)’.

## `Exit Status`

The value returned by a command to its caller. The value is restricted to eight bits, so the maximum value is 255.

## `Field`

A unit of text that is the result of one of the shell expansions. After expansion, when executing a command, the resulting fields are used as the command name and arguments.

## `Filename`

A string of characters used to identify a file.

## `Job`

A set of processes comprising a pipeline, and any processes descended from it, that are all in the same process group.

## `Job Control`

A mechanism by which users can selectively stop (suspend) and restart (resume) execution of processes.

## `Metacharacter`

A character that, when unquoted, separates words. A metacharacter is a space, tab, newline, or one of the following characters: ‘|’, ‘&’, ‘;’, ‘(’, ‘)’, ‘<’, or ‘>’.

## `Name`

A word consisting solely of letters, numbers, and underscores, and beginning with a letter or underscore. Names are used as shell variable and function names. Also referred to as an identifier.

## `Operator`

A control operator or a redirection operator.

## `Return Status`

A synonym for exit status.

## `Signal`

A mechanism by which a process may be notified by the kernel of an event occurring in the system.

## `Special Builtin`

A shell builtin command that has been classified as special by the posix standard.

## `Token`

A sequence of characters considered a single unit by the shell. It is either a word or an operator.

## `Word`

A sequence of characters treated as a unit by the shell. Words may not include unquoted metacharacters.