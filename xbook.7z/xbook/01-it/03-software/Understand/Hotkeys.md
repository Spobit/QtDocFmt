# `Hotkey`

|Name |Hotkey |Compoment |
|---|---|---|
|EditorHistory Previous   |Alt+Left        |Application
|EditorHistory Next       |Alt+Right       |Application
|History Back             |Alt+Shift+Left  |Information Browser
|History Forward          |Alt+Shift+Right |Information Browser
| | |
|Bookmarks                |Ctrl+B,B        |Application
|Add/Remove Bookmark      |Ctrl+B,T        |Editor
|Next Bookmark            |Ctrl+B,Right    |Editor
|Previous Bookmark        |Ctrl+B,Left     |Editor
| | |
|Search Annotations       |Ctrl+M,M        |Application
|Annotate Selected Entity |Ctrl+M,E        |Application
|Refresh Annotations      |Ctrl+M,F        |Application
