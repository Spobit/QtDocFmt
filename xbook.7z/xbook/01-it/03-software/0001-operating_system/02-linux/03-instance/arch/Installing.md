***
[TOC]
***

# `Verify the boot mode`

``` {class=line-numbers}
ls /sys/firmware/efi/efivars

如果目录存在,是UFI引导模式;否,BIOS模式.
```

# `Connect to the Internet`

``` {class=line-numbers}
# ping www.baidu.com
# ip link
# ip link set ens33 up
# dhcpcd ens33
```

# `Update mirrorlist`

``` {class=line-numbers}
pacman -Sy
pacman -S reflector
reflector --verbose -c China -l 10 --sort rate --save /etc/pacman.d/mirrorlist
```

# `Partition the disks`

``` {class=line-numbers}
//找到自己的硬盘设备/dev/nvme0n1
lsblk

//创建分区
fdisk /dev/nvme0n1
g
n
<Enter>
<Enter>
+200M
n
<Enter>
<Enter>
+200M
n
<Enter>
<Enter>
<Enter>
w

//Examine
fdisk -l
```

``` {class=line-numbers}
mkfs.fat -F32 /dev/nvme0n1p1
mkfs.ext4 /dev/nvme0n1p2
mkfs.ext4 /dev/nvme0n1p3

ext4文件系统的实现方式不同于fat,没有必要4K对齐.
```

``` {class=line-numbers}
//挂载系统位置
mount /dev/nvme0n1p3 /mnt

mkdir /mnt/boot
mount /dev/nvme0n1p2 /mnt/boot

mkdir /mnt/boot/efi
mount /dev/nvme0n1p1 /mnt/boot/efi

//Examine
lsblk
```

# `7. Install the base packages`

``` {class=line-numbers}
pacstrap /mnt base base-devel net-tools linux-headers wpa_supplicant
```

# `8. Fstab`

``` {class=line-numbers}
genfstab -U /mnt >> /mnt/etc/fstab
```

# `9. Chroot`

``` {class=line-numbers}
arch-chroot /mnt
```

# `10. Localization`

``` {class=line-numbers}
# vi /etc/locale.gen  ==> 删除 "en_US.UTF-8 UTF-8" "zh_CN.UTF-8 UTF-8" 前面的#号.
# locale-gen
```

``` {class=line-numbers}
echo LANG=en_US.UTF-8 >> /etc/locale.conf
```

# `11. Time zone`

``` {class=line-numbers}
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
vi /etc/localtime ==>CST-8 ==> CST-0
hwclock --systohc
date
```

# `12. Network configuration`

``` {class=line-numbers}
echo eit-pc >> /etc/hostname
```

``` {class=line-numbers}
vi /etc/hosts

127.0.0.1    localhost
::1          localhost
127.0.1.1    eit-pc.localdomain    eit-pc
```

# `13. Initramfs`

``` {class=line-numbers}
# mkinitcpio -p linux
```

# `14. Root password`

``` {class=line-numbers}
# passwd
```

# `15. Add user`

``` {class=line-numbers}
# useradd -m -G wheel eit
# passwd eit

// remember to open sudo privillige for wheel group in /etc/sudoers
# nano /etc/sudoers
# %wheel ALL=(ALL) ALL ==> %wheel ALL=(ALL)
```

# `16. Boot loader`

``` {class=line-numbers}
# pacman -S grub efibootmgr
# grub-install --target=x86_64-efi --efi-directory=/boot/eif --recheck
# grub-mkconfig -o /boot/grub/grub.cfg

这里可以与 "/etc/fstab" 对下,可能导致系统启动不了.
```

# `17. Reboot`

```
# exit
# umount -R /mnt
# reboot
```

# `Drivers`

## `video card driver`

intel:

``` {class=line-numbers}
sudo pacman -S xf86-video-intel
```

amd:

``` {class=line-numbers}
sudo pacman -S xf86-video-ati
```

nvidia:

``` {class=line-numbers}
sudo pacman -S xf86-video-nouveau
```

wmware:

``` {class=line-numbers}
sudo pacman -S xf86-video-wmware
```

common:

``` {class=line-numbers}
sudo pacman -S xf86-video-vesa
```

## `mouse driver`

vmware:

``` {class=line-numbers}
sudo pacman -S xf86-input-vmmouse
```

mormal:

``` {class=line-numbers}
sudo pacman -S xf86-input-mouse
```

## `touch pad`

``` {class=line-numbers}
sudo pacman -S xf86-input-synaptics
```

also see "[SOLVED] touchpad probelm.md".

# `xorg`

``` {class=line-numbers}
$ sudo pacman -S xorg-server xorg-xinit
$ sudo cp /etc/X11/xinit/xinitrc ~/.xinitrc
xxx
```

# `Desktop Environments`

``` {class=line-numbers}
$ sudo pacman -S xfce4-terminal
xxx
```

# `Window Managers`

``` {class=line-numbers}
$ sudo pacman -S i3

$ sudo vim ~/.xinitrc

# twm &
# xclock -geometry 50*50-1+1 &
# xterm -geometry 80*50+494+51 &
# xterm -geometry 80*20+494-1 &
# exec xterm -geometry 80*60+0+0 -name login

# exec i3 when exec startx
exec i3
```

# `Chinese Fonts`

``` {class=line-numbers}
$ sudo pacman -Ss | grep wqy wqy-zenhei ttf-fireflysung
$ sudo pacman -S wqy-bitmapfont wqy-microhei wqy-microhei-lite wqy-zenhei
xxx
```

# `Input Method`

see "[SOLVED] how to install wubi.md".

# `20. vm-tools`

## `设置固件类型`

添加好虚拟机,设置固件类型为UEFI(vmware中可在指定虚拟机的设置->选项->高级-> 固件类型中设置模式).

## `设置全屏为自动适应客户机`

启动archlinux,设置全屏为自动适应客户机(编辑->首选项->显示->全屏).

## `Install vm-tools`

```  {class=line-numbers}
点击虚拟机的安装wm-tools

$ sudo mkdir /mnt/vm-tools/
$ sudo mount /dev/cdrom/ /mnt/vm-tools/
$ ls /mnt/vm-tools/
$ tar -zxvf /mnt/vm-tools/VMwareTools.tar.gz
$ pwd
$ cd vmware-tools-distrib
$ ls
$ su
# for x in {0..6}; do mkdir -p /etc/init.d/rc${x}.d; done
# exit
$ sudo ./vmware-install.pl

$ sudo pacman -S asp
$ asp checkout open-vm-tools
$ cd open-vm-tools/repos/community-x86_64/
$ makepkg -s --asdeps

# cp vm* /usr/lib/systemd/system
# systemctl enable vmware-vmblock-fuse.service
# systemctl enable vmtoolsd.service

# reboot

# /etc/init.d/rc6.d/K99vmware-tools start   ==> 每次开机运行,就可以主虚机间复制
```

# `code dump`

``` {class=line-numbers}
examine limit of core dump:

$ ulimit -c -H
unlimited
$ ulimit -c -S
unlimited

$ su
# ulimit -c -S
0
# ulimit -c -H
unlimited

```

``` {class=line-numbers}
alter limit of core dump:

# echo "* soft core unlimited" > /etc/security/limits.conf
# echo "* hard core unlimited" >> /etc/security/limits.conf
# echo "root soft core unlimited" >> /etc/security/limits.conf
# echo "root hard core unlimited" >> /etc/security/limits.conf
```

``` {class=line-numbers}
set placement of core dump:

# echo "/tmp/core-%e-%t-%p-%s" > /proc/sys/kernel/core_pattern

%e: programe name
%t: time, seconds
%p: pid
%s: signal who cause the coredump
```