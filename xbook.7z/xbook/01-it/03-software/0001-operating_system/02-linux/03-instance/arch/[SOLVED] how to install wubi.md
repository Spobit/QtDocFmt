***
Reference:
- `https://wiki.archlinux.org/index.php/IBus`

***
[toc]
***



# `Install chinese fonts`

``` {class=line-numbers}{class=line-numbers}
$ sudo pacman -Ss | grep wqy
xxx
$ sudo pacman -S wqy? wqy? wqy? wqy?
```

`Install Input Method`

``` {class=line-numbers}{class=line-numbers}
$ sudo pacman -S ibus ibus-table ibus-table-chinese
xxx
```

# `Configuration`

``` {class=line-numbers}
$ sudo echo >> /etc/profile
$ sudo echo export GTK_IM_MODULE=ibus >> /etc/profile
$ sudo echo export XMODIFIERS=@im=ibus >> /etc/profile
$ sudo echo export QT_IM_MODULE=ibus >> /etc/profile
$ source /etc/profile
$ ibus-setup
xxx
```

# `Set Auto Run when power on`

``` {class=line-numbers}
$ echo >> ~/.config/i3/config
$ echo "# Set auto run input method when power on" >> ~/.config/i3/config
$ echo "exec ibus-daemon -d" >> ~/.config/i3/config
xxx
```