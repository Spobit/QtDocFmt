***
Reference: [泰晓科技](http://tinylab.org/)
***
[toc]
***

# `Make Environment`

See [linux-0.11-lab](https://github.com/Spobit/linux-0.11-lab).