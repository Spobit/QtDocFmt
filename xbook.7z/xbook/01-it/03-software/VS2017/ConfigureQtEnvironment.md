1. install vs.
2. install qt.
3. install "Qt Visual studio Tools" Extension in vs.
4. Configure "Qt VS Tools" in vs.
5. Solution -> Properties -> Debug Source File -> Directories containing source codes:
   add pos: "C:\\_App\\Qt\\5.12.1\\Src"