***
[TOC]
***

# `Plugins`

Qt Visual studio Tools ==> coding use qt.
Trim Copy
Rylogic.TextAligner


# `HotKeys`
EditorContextMenus.CodeWindow.ToggleHeaderCodeFile ==> Qt.F4
Edit.LienOpenAbove ==> Qt.Ctrl+Shelf+Enter
Edit.LienOpenBelow ==> Qt.Ctrl+Enter
View.NavigateForward ==> Qt.Alt+LeftArrow
View.NavigateBackward ==> Qt.Alt+RightArrow
Edit.GoToDefinition ==> Qt.F2
Edit.GoToDeclaration ==> Qt.Atl+F2
Window.CloseDocumentWindow ==> Qt.Ctrl+W