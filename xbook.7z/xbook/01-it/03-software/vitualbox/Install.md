

# `Install`

$ sudo pacman -S virtuabox

$ 2 (virtualbox-host-modules-arch)

# `Accessing host USB devices in guest`
$ groups <user_name>
$ gpasswd -a <user_name> vboxusers
$ groups <user_name>