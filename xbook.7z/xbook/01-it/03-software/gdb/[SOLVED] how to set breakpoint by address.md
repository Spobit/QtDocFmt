```
// add asterisk before address.
(gdb) b *0x7ffff3754bb0 if *$rsi == 3
Breakpoint 2 at 0x7ffff3754bb0
```