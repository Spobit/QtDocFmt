

```
// Custom styles.

// hr ****************************************************************************
hr {
    margin: 8px 0 !important;
    border: 0px solid red !important;
    padding: 0 !important;

    background-color: rgba(27, 36, 38, 1) !important;
    height: 2px !important;
    
    overflow: hidden !important;
    box-sizing: content-box !important;
    border-bottom: 1px solid #ddd !important;
    box-shadow: 0px 2px 2px #222 !important;
    
    background-image: repeating-linear-gradient(-45deg, #000, #000 4px, transparent 4px, transparent 8px);
}

// header ****************************************************************************
h1, h2, h3, h4, h5, h6 {
    ///> layout
    // frame
    margin: 16px 0px 16px 0px;
    border: 0px solid #f00;
    padding: 0px !important;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: bold;
    color: black;
}

// page ****************************************************************************
p {
    ///> layout
    // frame
    margin: 8px 0px 8px 0px;
    border: 0px solid #f00;
    padding: 0px;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: normal;
    color: black;
}

// table ****************************************************************************
table, thead, tbody, tr {
    ///> layout
    // frame
    margin: 8px 0px 8px 0px;
    border: 0px solid #f00;
    padding: 0px;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: normal;
    color: black;
}

thead > tr > th {
    ///> layout
    // frame
    margin: 0px;
    border: 0px solid #f00;
    border-top: 2px solid #ddd;
    border-bottom: 2px solid #ddd;
    padding: 4px 16px;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: bord;
    color: black;
}

tbody > tr > td {
    ///> layout
    // frame
    margin: 0px 0px 0px 0px;
    border: 0px solid #f00;
    border-top: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
    padding: 4px 16px;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: normal;
    color: black;
}

// pre ***************************************************************
pre {
    ///> layout
    // frame
    margin: 0px 0px 0px 0px;
    border: 0px solid #f00;
    padding: 8px !important;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: normal;
    color: black;
}

// code ***************************************************************
code {
    ///> layout
    // frame
    margin: 0px 0px 0px 0px !important;
    border: 0px solid #f00 !important;
    padding: 0 4px !important !important;
    // height
    /* height: 0px; */
    line-height: 1.2 !important;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01" !important;
    font-size: 16px !important;
    font-style: normal !important;
    font-weight: normal !important;
    color: #000 !important;
    // color
    background-color: #0000ff15 !important;
}

// ol ul ***************************************************************
li {
    ///> layout
    // frame
    margin: 8px 0px 8px 0px;
    border: 0px solid #f00;
    padding: 0px;
    // height
    /* height: 0px; */
    line-height: 1.2;
    ///> fonts
    font-family: "Fixedsys Excelsior 3.01";
    font-size: 16px;
    font-style: normal;
    font-weight: normal;
    color: black;
}
```

